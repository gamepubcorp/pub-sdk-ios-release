//
//  PubPurchaseData.h
//  PubSDK
//
//  Created by gamepub on 2020/09/03.
//  Copyright © 2020 gamepub. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PubPurchaseData : NSObject
@property (nonatomic) NSString *productId;

@property (nonatomic) NSInteger qty;
@property (nonatomic) NSString *orderId; //transactionIdentifier
@property (nonatomic) NSString *purchaseTime;
@property (nonatomic) NSString *purchaseToken; //receipt token
@end

NS_ASSUME_NONNULL_END
