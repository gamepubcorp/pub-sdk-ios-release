//
//  RespAppPurchase.h
//  PubSDK
//
//  Created by gamepub on 2020/08/31.
//  Copyright © 2020 gamepub. All rights reserved.
//

#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RespAppPurchase : JSONModel
@property (nonatomic) NSInteger intDate;
@property (nonatomic) NSString *tid;
@property (nonatomic) NSInteger status;
@property (nonatomic) NSString *serverId;
@property (nonatomic) NSString *playerId;
@property (nonatomic) NSString *productId;
@end

NS_ASSUME_NONNULL_END
