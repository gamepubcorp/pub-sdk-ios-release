//
//  PubApiClient.h
//  PubSDK
//
//  Created by gamepub on 2020/07/09.
//  Copyright © 2020 gamepub. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PubEnumType.h"
#import "PubFirebaseUserProfile.h"

NS_ASSUME_NONNULL_BEGIN


typedef void (^PubLoginResultCallback)(NSString *_Nullable loginResult,
                                       NSError *_Nullable error);

typedef void (^PubUnitResultCallback)(NSString *_Nullable unitResult,
                                      NSError *_Nullable error);


@interface PubApiClient : NSObject

+ (instancetype)getInstance;

@property (nonatomic) NSInteger          projectID;
@property (nonatomic) AccountServiceType serviceType;
@property (nonatomic) UIViewController  *instanceVC;
@property (nonatomic) NSArray           *languageList;

@property (nonatomic, strong) PubLoginResultCallback loginCallback;

- (void) setupSDK:(NSString *)domainURL
       completion:(nullable PubUnitResultCallback)completion;

- (void) loginWithGamepub:(LoginType)loginType
              serviceType:(AccountServiceType)accountServiceType
           viewController:(UIViewController *)viewController
               completion:(nullable PubLoginResultCallback)completion;

- (void) logout:(nullable PubUnitResultCallback)completion;

- (void) secede:(nullable PubUnitResultCallback)completion;
- (void) secedeCancel:(LoginType)loginType
           completion:(nullable PubUnitResultCallback)completion;

- (void) userInfoUpdate:(NSString *)languageCode
                   push:(BOOL)push
              pushNight:(BOOL)pushNight
                 pushAd:(BOOL)pushAd
             completion:(nullable PubUnitResultCallback)completion;

- (NSString *) getLoginType;
- (NSString *) getLanguageList;
- (NSString *) getProductList;

- (void) versionCheck:(nullable PubUnitResultCallback)completion;
- (void) openNotice:(nullable PubUnitResultCallback)completion;
- (void) openHelpURL:(UIViewController*)viewController
          completion:(nullable PubUnitResultCallback)completion;

- (void) openPolicyLinkSafariView:(UIViewController*)viewController
                       policyType:(PolicyType)policyType
                       completion:(nullable PubUnitResultCallback)completion;

- (void) imageBanner:(NSString*)ratioWidth
         ratioHeight:(NSString*)ratioHeight
          completion:(nullable PubUnitResultCallback)completion;

- (void) couponUse:(NSString*)key
          serverId:(NSString*)serverId
          playerId:(NSString*)playerId
               etc:(NSString*)etc
        completion:(nullable PubUnitResultCallback)completion;

- (void) purchaseLaunch:(NSString*)pid
               serverId:(NSString*)serverId
               playerId:(NSString*)playerId
                    etc:(NSString*)etc
             completion:(nullable PubUnitResultCallback)completion;

- (void) setDeviceToken:(NSString*)token;

- (void) pingListener:(nullable PubUnitResultCallback)completion;
- (void) startPing;
- (void) stopPing;


@end

NS_ASSUME_NONNULL_END
