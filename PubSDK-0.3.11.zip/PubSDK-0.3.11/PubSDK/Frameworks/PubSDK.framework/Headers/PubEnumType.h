//
//  PubEnumType.h
//  PubSDK
//
//  Created by gamepub on 2020/08/21.
//  Copyright © 2020 gamepub. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, LoginType)
{
    LOGIN_NONE,
    GOOGLE,
    FACEBOOK,    
    GUEST,
    APPLE,
};

typedef NS_ENUM(NSInteger, AccountServiceType)
{
    ACCOUNT_NONE,
    ACCOUNT_LOGIN,
    ACCOUNT_CONVERT,
    ACCOUNT_LINK,
};

typedef NS_ENUM(NSInteger, AccountStatus)
{
    U,
    B,
    S,
};

typedef NS_ENUM(NSInteger, PolicyType)
{
    PRIVACY,
    REFUND,
    SERVICE,
};

typedef NS_ENUM(NSInteger, PubApiResponseCode)
{
    PubApiResponseCodeSuccess = 1000,
    PubApiResponseCodeCancel = 1001,
    PubApiResponseCodeNetworkError = 1002,
    PubApiResponseCodeServerError = 1003,
    PubApiResponseCodeAuthenticationAgentError = 1004,
    PubApiResponseCodeUserIPBlock = 1005,
    PubApiResponseCodeServiceMaintenance = 1006,
    PubApiResponseCodeInternalError = 1007,
    PubApiResponseCodePurchaseError = 1008,
};

NS_ASSUME_NONNULL_BEGIN

@interface PubEnumType : NSObject

+ (NSString*) loginTypeStringFromEnum:(LoginType)type;

+ (NSString*) policyTypeStringFromEnum:(PolicyType)type;

@end

NS_ASSUME_NONNULL_END
