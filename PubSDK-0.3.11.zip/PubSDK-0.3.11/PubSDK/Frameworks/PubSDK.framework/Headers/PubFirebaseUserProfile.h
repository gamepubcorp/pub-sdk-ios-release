//
//  PubFirebaseUserProfile.h
//  PubSDK
//
//  Created by gamepub on 2021/02/22.
//  Copyright © 2021 gamepub. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PubEnumType.h"

NS_ASSUME_NONNULL_BEGIN

@interface PubFirebaseUserProfile : NSObject
@property (nonatomic) LoginType loginType;
@property (nonatomic) NSString* idToken;
@property (nonatomic) NSString* displayName;
@property (nonatomic) NSString* email;
@property (nonatomic) NSString* channelId;
@property (nonatomic) NSString* photoURL;
@end

NS_ASSUME_NONNULL_END
