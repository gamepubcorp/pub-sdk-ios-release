//
//  PubSDKApplicationDelegate.h
//  PubSDK
//
//  Created by gamepub on 2020/07/27.
//  Copyright © 2020 gamepub. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "PubFirebaseUserProfile.h"

NS_ASSUME_NONNULL_BEGIN

@protocol PubSDKLoginDelegate <NSObject>
- (void)onSDKLoginSuccess:(PubFirebaseUserProfile* _Nullable)userProfile;
- (void)onSDKLoginFailure:(NSError* _Nullable)error;
@end

@interface PubSDKApplicationDelegate : NSObject

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@property (class, nonatomic, readonly, strong) PubSDKApplicationDelegate *sharedInstance;

@property (nonatomic, weak) id<PubSDKLoginDelegate>     loginDelegate;


- (BOOL)application:(UIApplication *)application
didFinishLaunchingWithOptions:(nullable NSDictionary<UIApplicationLaunchOptionsKey, id> *)launchOptions;


- (void)googleAuth:(UIViewController*)uiview;
- (void)facebookAuth:(UIViewController*)uiview;
- (void)appleAuth:(UIViewController*)uiview;
- (void)guestAuth;

- (void)logout:(void (^)(NSString *))completion;

@end

NS_ASSUME_NONNULL_END
